const dell = {
  brand: "dell",
  harddisk: "2tb",
  color: "black",
};
console.log("in async");
const promise = new Promise((resolve, reject) => {
  setTimeout(() => {
    resolve(dell);
  }, 3000);
});
function method1() {
  promise.then((res) => {
    console.log(res);
  });
}
method1();
