// let user = [
//   { fname: "pranjal", name: "verma", age: 25 },
//   { fname: "a", name: "e", age: 26 },
//   { fname: "b", name: "f", age: 32 },
//   { fname: "c", name: "g", age: 24 },
//   { fname: "d", name: "h", age: 45 },
// ];

// // output = ['pranjal' 'a', 'c']

// const output = user.reduce((acc, curr) => {
//   if (curr.age <= 26) {
//     acc.push(curr.fname);
//   }
//   return acc;
// }, []);

// console.log(output);
let obj = {
  firstnam: "pranjal",
  lastname: "verma",
};

function printName(hometown, state) {
  console.log(
    this.firstnam + " " + this.lastname + " " + hometown + " " + state
  );
}
// let obj2 = {
//   firstnam: "Ram",
//   lastname: "Shyam",
// };

// let output = printName.bind(obj2, "noida");
// console.log("I am from bind", output("UP"));

// console.log(printName.call(obj2, "delhi", "delhi"));

// console.log(printName.apply(obj2, ["hansi", "haryana"]));

// polyfill for bind :

// Function.prototype.myBind = function (...args) {
//   let obj = this;
//   let params = args.slice(1);
//   return function (...args2) {
//     obj.apply(args[0], [...params, ...args2]);
//   };
// };

let obj2 = {
  firstnam: "Ram",
  lastname: "Shyam",
};
// let output = printName.myBind(obj2, "noida", "UP");
// output();

// Function.prototype.myBind = function (scope, ...args) {
//   scope._this = this;
//   //debugger;
//   return function () {
//     return scope._this([...args]);
//     //debugger;
//   };
// };

// Function.prototype.myCall = function (scope, ...args) {
//   scope._this = this;
//   //debugger;
//   return scope._this(...args);
// };

// Function.prototype.myApply = function (scope, args) {
//   scope._this = this;
//   //debugger;
//   return scope._this(...args);
// };

Function.prototype.myBind = function (...args) {
  let scope = this;
  params = args.slice(1);
  return function (...arg2) {
    scope.apply(args[0], [...params, ...arg2]);
  };
};

Function.prototype.myCall = function (scope, ...args) {
  scope._this = this;
  return scope._this(...args);
};

Function.prototype.myApply = function (scope, args) {
  scope._this = this;
  return scope._this(...args);
};

let output = printName.myBind(obj2, "noida");
output("delhi");

printName.myCall(obj2, "delhi", "delhi");
printName.myApply(obj2, ["uk", "uk"]);

// code for forms

const form = document.getElementById("form");
const username = document.getElementById("username");
const email = document.getElementById("email");
const password = document.getElementById("password");
const password2 = document.getElementById("password2");

form.addEventListener("submit", (e) => {
  e.preventDefault();

  checkInputs();
});

function checkInputs() {
  // trim to remove the whitespaces
  const usernameValue = username.value.trim();
  const emailValue = email.value.trim();
  const passwordValue = password.value.trim();
  const password2Value = password2.value.trim();

  if (usernameValue === "") {
    setErrorFor(username, "Username cannot be blank");
  } else {
    setSuccessFor(username);
  }

  if (emailValue === "") {
    setErrorFor(email, "Email cannot be blank");
  } else if (!isEmail(emailValue)) {
    setErrorFor(email, "Not a valid email");
  } else {
    setSuccessFor(email);
  }

  if (passwordValue === "") {
    setErrorFor(password, "Password cannot be blank");
  } else {
    setSuccessFor(password);
  }

  if (password2Value === "") {
    setErrorFor(password2, "Password2 cannot be blank");
  } else if (passwordValue !== password2Value) {
    setErrorFor(password2, "Passwords does not match");
  } else {
    setSuccessFor(password2);
  }
}

function setErrorFor(input, message) {
  const formControl = input.parentElement;
  const small = formControl.querySelector("small");
  formControl.className = "form-control error";
  small.innerText = message;
}

function setSuccessFor(input) {
  const formControl = input.parentElement;
  formControl.className = "form-control success";
}

function isEmail(email) {
  return /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(
    email
  );
}
