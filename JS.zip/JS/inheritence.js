function Employee(name, exp) {
  this.name = name;
  this.exp = exp;
}
Employee.prototype.getDetails = function () {
  console.log(`employee details : ${this.name} and exp : ${this.exp}`);
};

const emp1 = new Employee("pranjal", 0);
console.log(emp1);
console.log(emp1.getDetails());

function Programmer(name, exp, language) {
  Employee.call(this, name, exp);
  this.language = language;
}
Programmer.prototype = Object.create(Employee.prototype);
// Programmer.prototype.constructor = Programmer;

progEmp1 = new Programmer("donal", 3, "JAva");
console.log(progEmp1);
console.log(progEmp1.getDetails());

// manully;

//////// class based syntax :

class Employee {
  constructor(name, exp) {
    this.name = name;
    this.exp = exp;
  }

  getDetails() {
    console.log(
      //   `this is details : name is ${this.name} and exp is ${this.exp} `
      `I am inside get details`
    );
  }

  static add(a, b) {
    return a + b;
  }
}

console.log(Employee.add(3, 6));

let emplo = new Employee("barak", 4);
console.log(emplo.getDetails());

console.log(emp1);
