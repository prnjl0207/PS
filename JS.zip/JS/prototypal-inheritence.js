// Prototype and Prototypal inhritence

function Employee(name, exp) {
  this.name = name;
  this.experience = exp;
}

Employee.prototype.getSalary = function () {
  return `${this.name} has salary of 20k`;
};

let emp1 = new Employee("pranjal", 3);
let emp2 = new Employee("verma", 3);
console.log(emp1.getSalary());
console.log(emp2.getSalary());

function Programmer(name, exp, language) {
  Employee.call(this, name, exp);
  this.language = language;
}
// Programmer.prototype = Object.create(Employee.prototype);
// Programmer.prototype.constructor = Programmer;
let rohan = new Programmer("rohan", 2, "js");
console.log(rohan);
// console.log(rohan.getSalary());

// Class based inheritence in ES6
class EmployeeOne {
  constructor(name, exp) {
    this.name = name;
    this.experience = exp;
  }
  reim() {
    return `this is ${this.name} our employee one`;
  }

  static add(a, b) {
    return a + b;
  }
}

let empone1 = new EmployeeOne("naresh", 56);
console.log(empone1);
console.log(empone1.reim());

class ProgrammerOne extends EmployeeOne {
  constructor(name, exp, language) {
    super(name, exp);
    this.language = language;
  }
  static multilply(a, b) {
    return a * b;
  }
}

let prog1 = new ProgrammerOne("rajneesh", 8);
console.log(prog1);
console.log(prog1.reim());

console.log(ProgrammerOne.multilply(1, 2));
//////////////////////////////////////////////////////////

let element = document.getElementById("btn");
element.addEventListener("click", method1);

let element1 = document.getElementById("btn1");
element1.addEventListener("click", method2);
const dell = {
  brand: "dell",
  harddisk: "2tb",
  color: "black",
};
console.log("in async");
const promise = new Promise((resolve, reject) => {
  setTimeout(() => {
    resolve(dell);
  }, 3000);
});
function method1() {
  promise.then((res) => {
    console.log(res);
  });
}

async function method2() {
  let data = await promise;
  console.log(data);
}

async function func() {
  let data = await `hey`;
  console.log(data);
}
func();

let element3 = document.getElementById("btn2");
element3.addEventListener("click", method3);

let user = fetch("https://jsonplaceholder.typicode.com/todos/1").then(
  (response) => response.json()
);

async function method3() {
  let res = await user;
  console.log(res);
}
